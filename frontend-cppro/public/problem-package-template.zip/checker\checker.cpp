﻿#include <bits/stdc++.h>
using namespace std;

static string readTrimmed(const string& path) {
    ifstream in(path);
    string s((istreambuf_iterator<char>(in)), istreambuf_iterator<char>());
    while (!s.empty() && isspace((unsigned char)s.back())) s.pop_back();
    return s;
}

int main(int argc, char** argv) {
    if (argc != 4) {
        cerr << "Usage: checker <input> <contestant_output> <official_output>\n";
        return 2;
    }
    string contestant = readTrimmed(argv[2]);
    string official = readTrimmed(argv[3]);
    if (contestant == official) {
        cout << "relative_point 1\n";
        return 0;
    }
    cout << "Wrong Answer\n";
    return 1;
}
