﻿# A Plus B

## Statement

Given two integers `a` and `b`, print their sum.

## Input

One line contains two integers `a` and `b`.

## Output

Print one integer: `a + b`.

## Constraints

```text
-10^9 <= a, b <= 10^9
```
