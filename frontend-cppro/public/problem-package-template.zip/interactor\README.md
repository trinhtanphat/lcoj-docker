﻿# Interactor notes

Interactive tasks are not executed by the current standard judge runner yet.
Keep `interactor/` files in the package for admin review, then wire a dedicated runner before publishing an interactive problem.
