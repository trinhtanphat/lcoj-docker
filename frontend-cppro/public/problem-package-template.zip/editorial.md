﻿# Editorial - A Plus B

Read two integers and print their sum.

Complexity: `O(1)` time and `O(1)` memory.
