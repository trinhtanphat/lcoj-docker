﻿# ITCoder Problem Package Template

Required:
- `problem.json`: metadata.
- `statement.md`: public problem statement.
- `editorial.md`: hidden/admin editorial.
- `samples/*.in` and `samples/*.out`: public samples.
- `tests/*.in` or `tests/*.inp` with matching `tests/*.out`: hidden judge data.

Recommended:
- `solutions/ac.cpp`: hidden accepted/reference solution.
- `checker/checker.cpp`: optional C++ checker. Contract: `checker input contestant_output official_output`.
- `tools/`: generators or validators. These are stored as hidden admin attachment.
- `interactor/`: interactive task files. Current standard runner does not execute interactors automatically.

Problem types:
- standard: exact `.out` matching; omit checker unless custom validation is needed.
- heuristic: include benchmark `.out` files and a checker that prints `relative_point <0..1>`.
- interactive: include statement and interactor sources, but publish only after a dedicated interactive runner is configured.
