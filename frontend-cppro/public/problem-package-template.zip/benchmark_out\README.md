﻿# Benchmark Outputs

For heuristic packages, put official benchmark outputs here when you do not want to keep them beside the inputs.
ITCoder pairs benchmark_out/001.out with tests/001.in by matching the base name.
The aliases answers/ and outputs/ are also supported.
